#define DO_CALL_TEST7 1
#include "call-test.c"
