#ifndef IPRANGE_IPSET_OPTIMIZE_H
#define IPRANGE_IPSET_OPTIMIZE_H

extern void ipset_optimize(ipset *ips);
extern void ipset_optimize_all(ipset *root);

#endif //IPRANGE_IPSET_OPTIMIZE_H
