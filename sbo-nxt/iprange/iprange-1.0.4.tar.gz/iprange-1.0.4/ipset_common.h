#ifndef IPRANGE_IPSET_COMMON_H
#define IPRANGE_IPSET_COMMON_H

extern ipset *ipset_common(ipset *ips1, ipset *ips2);

#endif //IPRANGE_IPSET_COMMON_H
