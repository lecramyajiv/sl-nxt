#ifndef IPRANGE_IPSET_MERGE_H
#define IPRANGE_IPSET_MERGE_H

extern void ipset_merge(ipset *to, ipset *add);

#endif //IPRANGE_IPSET_MERGE_H
