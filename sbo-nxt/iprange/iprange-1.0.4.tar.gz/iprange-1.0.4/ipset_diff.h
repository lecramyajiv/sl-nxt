#ifndef IPRANGE_IPSET_DIFF_H
#define IPRANGE_IPSET_DIFF_H

extern ipset *ipset_diff(ipset *ips1, ipset *ips2);

#endif //IPRANGE_IPSET_DIFF_H
