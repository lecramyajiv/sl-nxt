#ifndef IPRANGE_IPSET_REDUCE_H
#define IPRANGE_IPSET_REDUCE_H

extern void ipset_reduce(ipset *ips, size_t acceptable_increase, size_t min_accepted);

#endif //IPRANGE_IPSET_REDUCE_H
