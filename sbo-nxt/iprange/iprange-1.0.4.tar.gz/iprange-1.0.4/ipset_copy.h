#ifndef IPRANGE_IPSET_COPY_H
#define IPRANGE_IPSET_COPY_H

extern ipset *ipset_copy(ipset *ips1);

#endif //IPRANGE_IPSET_COPY_H
