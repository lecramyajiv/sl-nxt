#ifndef IPRANGE_IPSET_COMBINE_H
#define IPRANGE_IPSET_COMBINE_H

extern ipset *ipset_combine(ipset *ips1, ipset *ips2);

#endif //IPRANGE_IPSET_COMBINE_H
