#ifndef IPRANGE_IPSET_EXCLUDE_H
#define IPRANGE_IPSET_EXCLUDE_H

extern ipset *ipset_exclude(ipset *ips1, ipset *ips2);

#endif //IPRANGE_IPSET_EXCLUDE_H
