#define DO_CALL_TEST5 1
#include "call-test.c"
