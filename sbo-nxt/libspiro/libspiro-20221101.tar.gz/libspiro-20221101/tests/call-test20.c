#define DO_CALL_TEST20 1
#include "call-test.c"
