#define DO_CALL_TEST18 1
#include "call-test.c"
