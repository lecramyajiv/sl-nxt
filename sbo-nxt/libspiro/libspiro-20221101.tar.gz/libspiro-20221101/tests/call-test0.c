#define DO_CALL_TEST0 1
#include "call-test.c"
