#define DO_CALL_TEST1 1
#include "call-test.c"
