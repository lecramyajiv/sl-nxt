#define DO_CALL_TEST9 1
#include "call-test.c"
