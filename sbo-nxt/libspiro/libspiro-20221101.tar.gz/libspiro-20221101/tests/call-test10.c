#define DO_CALL_TEST10
#include "call-test.c"
