#define DO_CALL_TEST19 1
#include "call-test.c"
