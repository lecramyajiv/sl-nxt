#define DO_CALL_TEST12 1
#include "call-test.c"
