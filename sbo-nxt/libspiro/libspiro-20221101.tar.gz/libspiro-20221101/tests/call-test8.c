#define DO_CALL_TEST8 1
#include "call-test.c"
