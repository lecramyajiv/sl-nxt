#define DO_CALL_TEST16 1
#include "call-test.c"
