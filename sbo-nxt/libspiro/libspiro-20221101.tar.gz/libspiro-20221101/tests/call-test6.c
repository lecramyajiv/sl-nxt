#define DO_CALL_TEST6 1
#include "call-test.c"
