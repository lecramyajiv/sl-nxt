filter_names = ('DCTDecode', 'DCT')


def decode(binary, params):
    raise NotImplementedError('DCTDecode')