filter_names = ('JBIG2Decode',)


def decode(binary, params):
    raise NotImplementedError('JBIG2Decode')