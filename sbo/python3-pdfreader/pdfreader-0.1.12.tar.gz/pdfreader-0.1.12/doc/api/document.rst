pdfreader.document submodule
============================

.. automodule:: pdfreader.document

   .. autoclass:: pdfreader.document.PDFDocument

      .. autoattribute:: root
      .. autoattribute:: header
      .. autoattribute:: trailer

      .. autoproperty:: metadata
      .. automethod:: pages
      .. automethod:: build
      .. automethod:: locate_object
