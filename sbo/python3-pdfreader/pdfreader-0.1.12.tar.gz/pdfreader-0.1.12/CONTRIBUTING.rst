=========================
Contributing to pdfreader
=========================

*pdfreader* is an open source project. You're welcome to contribute:

* Code patches
* Bug reports
* Patch reviews
* Introduce new features
* Documentation improvements


*pdfreader* uses GitHub `issues <https://github.com/maxpmaxp/pdfreader/issues>`_ to keep track of bugs,
feature requests, etc.
